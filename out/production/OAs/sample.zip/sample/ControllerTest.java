package sample;

import static org.junit.jupiter.api.Assertions.*;

class ControllerTest {

    @org.junit.Before
    public void setUp() throws Exception {

    }

    @org.junit.After
    public void tearDown() throws Exception {

    }

    @org.junit.Test
    public void submitCreate() {

    }

    @org.junit.Test
    public void clearCreate() {

    }

    @org.junit.Test
    public void searchGet() {

    }

    @org.junit.Test
    public void updateSubmit() {

    }

    @org.junit.Test
    public void deleteSubmit() {

    }
}